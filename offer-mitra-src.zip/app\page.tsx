"use client";

import { useAccess } from "@/components/auth/AccessProvider";
import OfferForm from "@/components/generator/OfferForm";
import BannerGenerator from "@/components/preview/BannerGenerator";
import VideoGenerator from "@/components/preview/VideoGenerator";
import AccessCodeModal from "@/components/subscription/AccessCodeModal";
import BusinessTypeSelector from "@/components/onboarding/BusinessTypeSelector";
import { Loader2, Send, Sparkles, Video, Image as ImageIcon, Crown } from "lucide-react";
import { useState, useEffect } from "react";
import { db } from "@/lib/firebase";
import { collection, addDoc } from "firebase/firestore";
import { cn } from "@/lib/utils";
import { getBusinessType, BusinessType } from "@/lib/businessTypes";

export default function Home() {
  const { usageCount, isPro, loading, incrementUsage } = useAccess();
  const [isGenerating, setIsGenerating] = useState(false);
  const [showAccessModal, setShowAccessModal] = useState(false);
  const [showBusinessSelector, setShowBusinessSelector] = useState(false);
  const [generatedOffer, setGeneratedOffer] = useState<string | null>(null);
  const [lastInputData, setLastInputData] = useState<any>(null);
  const [outputMode, setOutputMode] = useState<'banner' | 'video'>('banner');

  // Check if business type is selected on mount
  useEffect(() => {
    const businessType = getBusinessType();
    if (!businessType) {
      setShowBusinessSelector(true);
    }
  }, []);

  const handleGenerate = async (data: any) => {
    // Check usage limit
    if (!isPro && usageCount >= 3) {
      setShowAccessModal(true);
      return;
    }

    setIsGenerating(true);
    setGeneratedOffer(null);
    setLastInputData(data);

    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      const result = await res.json();
      if (result.text) {
        setGeneratedOffer(result.text);
        incrementUsage();

        try {
          await addDoc(collection(db, "offers_history"), {
            ...data,
            generatedText: result.text,
            createdAt: Date.now(),
            isProUser: isPro
          });
        } catch (err) {
          console.warn("History save skipped", err);
        }
      } else {
        alert("Generation failed. Please check your API Key settings.");
      }
    } catch (e) {
      alert("Something went wrong.");
    } finally {
      setIsGenerating(false);
    }
  };

  if (loading) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-indigo-600" />
      </div>
    );
  }

  // No more Login needed

  return (
    <main className="min-h-screen bg-gray-50 pb-20">
      <header className="bg-white shadow-sm p-4 sticky top-0 z-10 flex justify-between items-center">
        <div>
          <h1 className="text-xl font-bold text-indigo-700 flex items-center gap-2">OfferMitra <span className="text-xs bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded-full">MVP</span></h1>
          <div className="flex items-center gap-4 text-xs text-gray-700 mt-1">
            {isPro ? (
              <span className="text-indigo-600 font-bold flex items-center gap-1">
                <Crown className="w-3 h-3 text-orange-400" /> Pro Member
              </span>
            ) : (
              <span>Free Uses Left: <span className="font-bold text-gray-900">{Math.max(0, 3 - usageCount)}/3</span></span>
            )}
          </div>
        </div>
        <div className="flex items-center gap-3">
          <a
            href="/admin"
            className="px-4 py-1.5 rounded-full text-xs font-bold bg-slate-200 text-slate-700 hover:bg-slate-300 transition-all"
          >
            Admin
          </a>
          <button
            onClick={() => setShowAccessModal(true)}
            className={cn(
              "px-4 py-1.5 rounded-full text-xs font-bold transition-all",
              isPro ? "bg-green-100 text-green-700" : "bg-indigo-600 text-white shadow-md shadow-indigo-100"
            )}
          >
            {isPro ? "Active Pro" : "Go Pro"}
          </button>
        </div>
      </header>

      <div className="p-4 max-w-lg mx-auto space-y-6">

        <div className="bg-white p-5 rounded-2xl shadow-sm border border-gray-100">
          <h2 className="text-lg font-bold text-gray-800 mb-4">Create New Offer</h2>
          <OfferForm onGenerate={handleGenerate} isGenerating={isGenerating} />
        </div>

        {generatedOffer && (
          <div className="bg-white p-5 rounded-2xl shadow-lg border border-purple-100 animate-in fade-in slide-in-from-bottom-4 space-y-6">

            <div>
              <h3 className="font-bold text-green-600 mb-2 flex items-center gap-2">
                ✅ Text Preview
              </h3>
              <textarea
                value={generatedOffer}
                onChange={(e) => setGeneratedOffer(e.target.value)}
                className="w-full h-32 bg-green-50 p-4 rounded-xl text-gray-800 border border-green-100 font-medium focus:ring-2 focus:ring-green-500 outline-none resize-none text-sm"
              />
              <a
                href={`https://wa.me/?text=${encodeURIComponent(generatedOffer)}`}
                target="_blank"
                rel="noreferrer"
                className="mt-2 w-full bg-[#25D366] hover:bg-[#20b85a] text-white font-bold py-3 rounded-xl shadow-md shadow-green-200 transition-all flex items-center justify-center gap-2"
              >
                <Send className="w-5 h-5" /> Share on WhatsApp
              </a>
            </div>

            <div className="border-t pt-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-purple-600 flex items-center gap-2">
                  🎨 Marketing Poster
                </h3>
                <div className="flex p-1 bg-gray-100 rounded-lg">
                  <button
                    onClick={() => setOutputMode('banner')}
                    className={cn(
                      "flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-md transition-all",
                      outputMode === 'banner' ? "bg-white text-indigo-700 shadow-sm" : "text-gray-500 hover:text-gray-700"
                    )}
                  >
                    <ImageIcon className="w-3 h-3" /> Static
                  </button>
                  <button
                    onClick={() => setOutputMode('video')}
                    className={cn(
                      "flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-md transition-all",
                      outputMode === 'video' ? "bg-white text-indigo-700 shadow-sm" : "text-gray-500 hover:text-gray-700"
                    )}
                  >
                    <Video className="w-3 h-3" /> Video Add
                  </button>
                </div>
              </div>

              {outputMode === 'banner' ? (
                <BannerGenerator
                  text={generatedOffer}
                  shopType={lastInputData?.shopType || "My Shop"}
                  shopName={lastInputData?.shopName}
                />
              ) : (
                <VideoGenerator
                  offerText={generatedOffer}
                  productName={lastInputData?.productName || ""}
                  discount={lastInputData?.discount || "Sale"}
                  shopType={lastInputData?.shopType || "Shop"}
                  shopName={lastInputData?.shopName}
                />
              )}
            </div>

          </div>
        )}

      </div>

      {/* Business Type Selector - First Time Only */}
      {showBusinessSelector && (
        <BusinessTypeSelector
          onSelect={(type: BusinessType) => {
            setShowBusinessSelector(false);
          }}
        />
      )}

      <AccessCodeModal
        isOpen={showAccessModal}
        onClose={() => setShowAccessModal(false)}
      />
    </main>
  );
}
