import { GoogleGenerativeAI } from "@google/generative-ai";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
    try {
        const { shopName, shopType, offerType, productName, discount, extraInfo, language } = await req.json();

        const apiKey = process.env.GEMINI_API_KEY;
        if (!apiKey || apiKey === "your_api_key_here") {
            // Mock Response for Demo/Guest Mode
            await new Promise(resolve => setTimeout(resolve, 1500)); // Fake delay
            return NextResponse.json({
                text: `✨ *Special Offer!* ✨\n\nGet the best deal on *${productName || "our products"}* at ${shopName || shopType}!\n\n🔥 ${discount ? `Flat ${discount} OFF!` : "Best Prices Guaranteed!"}\n🚀 ${extraInfo || "Visit us today!"}\n\nLimit time offer! Jaldi aayein! 🏃‍♂️💨`
            });
        }

        const genAI = new GoogleGenerativeAI(apiKey);
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

        const prompt = `
      You are a friendly Hindi copywriter for small local shops in India. 
      Generate a short, catchy WhatsApp message for ${shopName || `a ${shopType}`} shop.
      
      Details:
      - Shop Name: ${shopName || "Our Shop"}
      - Offer Type: ${offerType}
      - Product: ${productName}
      - Discount: ${discount || "Best Price"}
      - Extra Info: ${extraInfo || "Visit us today"}
      - Language Style: ${language} (Mix of Hindi and English, natural Hinglish)
      
      Output rules: 
      - Max 5 lines
      - Include urgency phrases like "Aaj hi le aayein!" or "Jaldi karein!"
      - Use 1-3 emojis suitable for the product
      - Do NOT include any intro text like "Here is the message", just the message.
      - Make it look good on WhatsApp (use *bold* for highlights).
    `;

        const result = await model.generateContent(prompt);
        const response = await result.response;
        const text = response.text();

        return NextResponse.json({ text });
    } catch (error) {
        console.error("Gemini Error:", error);
        return NextResponse.json({ error: "Failed to generate offer" }, { status: 500 });
    }
}
