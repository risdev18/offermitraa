import { NextResponse } from "next/server";
import fs from "fs";
import path from "path";

const ADMIN_SECRET = process.env.ADMIN_SECRET || "om-admin-123";
const DATA_FILE = path.join(process.cwd(), "data", "access-codes.json");

// Ensure data directory exists
function ensureDataDir() {
    const dataDir = path.join(process.cwd(), "data");
    if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
    }
    if (!fs.existsSync(DATA_FILE)) {
        fs.writeFileSync(DATA_FILE, JSON.stringify([]));
    }
}

// Read codes from file
function readCodes() {
    ensureDataDir();
    const data = fs.readFileSync(DATA_FILE, "utf-8");
    return JSON.parse(data);
}

// Write codes to file
function writeCodes(codes: any[]) {
    ensureDataDir();
    fs.writeFileSync(DATA_FILE, JSON.stringify(codes, null, 2));
}

export async function GET(req: Request) {
    const { searchParams } = new URL(req.url);
    const secret = searchParams.get("secret");

    if (secret !== ADMIN_SECRET) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    try {
        const codes = readCodes();
        // Sort by createdAt descending
        codes.sort((a: any, b: any) => b.createdAt - a.createdAt);
        return NextResponse.json(codes);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

export async function POST(req: Request) {
    try {
        const body = await req.json();
        const { code, expiryDays, secret } = body;

        if (secret !== ADMIN_SECRET) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const codes = readCodes();

        const newCode = {
            id: Date.now().toString() + Math.random().toString(36).substring(2, 9),
            code: code.trim().toUpperCase(),
            expiryDate: expiryDays ? Date.now() + (expiryDays * 24 * 60 * 60 * 1000) : null,
            isActive: true,
            isUsed: false,
            createdAt: Date.now()
        };

        codes.push(newCode);
        writeCodes(codes);

        return NextResponse.json(newCode);
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

export async function PATCH(req: Request) {
    try {
        const body = await req.json();
        const { id, isActive, secret } = body;

        if (secret !== ADMIN_SECRET) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const codes = readCodes();
        const codeIndex = codes.findIndex((c: any) => c.id === id);

        if (codeIndex === -1) {
            return NextResponse.json({ error: "Code not found" }, { status: 404 });
        }

        codes[codeIndex].isActive = isActive;
        writeCodes(codes);

        return NextResponse.json({ success: true });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}

export async function DELETE(req: Request) {
    try {
        const { searchParams } = new URL(req.url);
        const id = searchParams.get("id");
        const secret = searchParams.get("secret");

        if (secret !== ADMIN_SECRET) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        if (!id) return NextResponse.json({ error: "Missing ID" }, { status: 400 });

        const codes = readCodes();
        const filteredCodes = codes.filter((c: any) => c.id !== id);

        if (filteredCodes.length === codes.length) {
            return NextResponse.json({ error: "Code not found" }, { status: 404 });
        }

        writeCodes(filteredCodes);

        return NextResponse.json({ success: true });
    } catch (error: any) {
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
