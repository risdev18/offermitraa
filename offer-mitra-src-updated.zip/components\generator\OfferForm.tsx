"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { Send, Wand2, Store, Tag, Loader2, Phone, Calendar } from "lucide-react";
import { ShopType, OfferType, Language } from "@/types";
import { cn } from "@/lib/utils";
import VoiceInput from "./VoiceInput";
import AIIdeas from "./AIIdeas";
import { getBusinessType, getBusinessConfig } from "@/lib/businessTypes";

interface OfferFormProps {
    onGenerate: (data: any) => void;
    isGenerating: boolean;
}

export default function OfferForm({ onGenerate, isGenerating }: OfferFormProps) {
    const { register, handleSubmit, setValue, watch, formState: { errors } } = useForm();
    const [language, setLanguage] = useState<Language>('hinglish');
    const [showContactField, setShowContactField] = useState(false);

    const businessType = getBusinessType();
    const businessConfig = businessType ? getBusinessConfig(businessType) : null;

    const shopType = watch("shopType") || "kirana";

    const onSubmit = (data: any) => {
        onGenerate({
            ...data,
            language,
            businessType: businessType || 'grocery',
            cta: businessConfig?.defaultCTA || 'Call Now'
        });
    };

    const handleVoiceInput = (text: string) => {
        const currentName = watch("productName") || "";
        setValue("productName", currentName + (currentName ? " " : "") + text);
    };

    const handleSelectSuggestion = (s: any) => {
        setValue("productName", s.product);
        setValue("discount", s.discount);
        setValue("extraInfo", s.title);
    };

    return (
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">

            {/* AI Ideas Section */}
            <AIIdeas shopType={shopType} onSelectSuggestion={handleSelectSuggestion} />

            {/* Shop Name Input - BIGGER, MORE PROMINENT */}
            <div className="space-y-2">
                <label className="text-sm font-bold text-gray-900 flex items-center gap-2">
                    <Store className="w-5 h-5" style={{ color: businessConfig?.primaryColor || '#6366f1' }} />
                    दुकान का नाम (Shop Name)
                </label>
                <input
                    type="text"
                    placeholder="Ex: Sharma Kirana, Global Medicals..."
                    {...register("shopName", { required: "Shop name is required" })}
                    className="w-full p-4 bg-white border-2 border-gray-300 rounded-xl focus:ring-2 focus:border-indigo-500 outline-none text-gray-900 placeholder:text-gray-500 font-bold text-lg shadow-sm"
                />
                {errors.shopName && <p className="text-red-600 text-xs font-bold">✗ दुकान का नाम ज़रूरी है</p>}
            </div>

            {/* Contact Number (Optional but Encouraged) */}
            <div className="space-y-2">
                <div className="flex items-center justify-between">
                    <label className="text-sm font-bold text-gray-900 flex items-center gap-2">
                        <Phone className="w-5 h-5 text-green-600" />
                        मोबाइल नंबर (Optional)
                    </label>
                    <button
                        type="button"
                        onClick={() => setShowContactField(!showContactField)}
                        className="text-xs text-indigo-600 font-bold hover:text-indigo-800"
                    >
                        {showContactField ? 'Hide' : '+ Add Number'}
                    </button>
                </div>
                {showContactField && (
                    <div className="space-y-2">
                        <input
                            type="tel"
                            placeholder="9876543210"
                            {...register("contactNumber", {
                                pattern: {
                                    value: /^[0-9]{10}$/,
                                    message: "10 अंकों का नंबर डालें"
                                }
                            })}
                            className="w-full p-3 bg-white border-2 border-gray-300 rounded-xl focus:ring-2 focus:border-green-500 outline-none text-gray-900 font-mono text-lg"
                            maxLength={10}
                        />
                        {errors.contactNumber && <p className="text-red-600 text-xs font-bold">✗ {errors.contactNumber.message as string}</p>}
                        <p className="text-xs text-gray-600">💡 नंबर डालने से ज़्यादा ग्राहक आएंगे</p>
                    </div>
                )}
            </div>

            {/* Product Input with Voice - BIGGER */}
            <div className="space-y-2">
                <label className="text-sm font-bold text-gray-900">प्रोडक्ट / सर्विस</label>
                <div className="flex gap-2">
                    <input
                        type="text"
                        placeholder="Ex: Basmati Rice, iPhone 15, Paracetamol..."
                        {...register("productName", { required: "Product name is required" })}
                        className="flex-1 p-4 bg-white border-2 border-gray-300 rounded-xl focus:ring-2 focus:border-indigo-500 outline-none text-gray-900 placeholder:text-gray-500 font-bold text-lg shadow-sm"
                    />
                    <VoiceInput onTranscript={handleVoiceInput} />
                </div>
                {errors.productName && <p className="text-red-600 text-xs font-bold">✗ प्रोडक्ट का नाम ज़रूरी है</p>}
            </div>

            {/* Discount - BIGGER */}
            <div className="space-y-2">
                <label className="text-sm font-bold text-gray-900">डिस्काउंट / ऑफर</label>
                <input
                    type="text"
                    placeholder="Ex: ₹99, 50% OFF, Buy 1 Get 1"
                    {...register("discount")}
                    className="w-full p-4 bg-white border-2 border-gray-300 rounded-xl focus:ring-2 focus:border-indigo-500 outline-none text-gray-900 placeholder:text-gray-500 font-bold text-lg shadow-sm"
                />
                <p className="text-xs text-gray-600">💡 Tip: ₹99 converts better than ₹100</p>
            </div>

            {/* Extra Info (Optional) */}
            <div className="space-y-2">
                <label className="text-sm font-bold text-gray-900">Extra Info (Optional)</label>
                <input
                    type="text"
                    placeholder="Free delivery, Limited stock..."
                    {...register("extraInfo")}
                    className="w-full p-3 bg-white border-2 border-gray-200 rounded-xl focus:ring-2 focus:border-indigo-500 outline-none text-gray-900 placeholder:text-gray-500 font-medium"
                />
            </div>

            {/* Business Since (Trust Builder - Optional) */}
            <div className="space-y-2">
                <div className="flex items-center justify-between">
                    <label className="text-sm font-bold text-gray-900 flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-blue-600" />
                        दुकान कब से है? (Optional)
                    </label>
                </div>
                <select
                    {...register("businessSince")}
                    className="w-full p-3 bg-white border-2 border-gray-200 rounded-xl focus:ring-2 focus:border-indigo-500 outline-none text-gray-900 font-medium"
                >
                    <option value="">Select Year</option>
                    {Array.from({ length: 30 }, (_, i) => new Date().getFullYear() - i).map(year => (
                        <option key={year} value={year}>Since {year}</option>
                    ))}
                </select>
                <p className="text-xs text-gray-600">💡 "Since 2010" builds trust</p>
            </div>

            {/* Language Toggle */}
            <div className="flex p-1 bg-gray-100 rounded-lg">
                <button
                    type="button"
                    onClick={() => setLanguage('hindi')}
                    className={cn(
                        "flex-1 py-2.5 text-sm font-bold rounded-md transition-all",
                        language === 'hindi' ? "bg-white text-indigo-700 shadow-sm" : "text-gray-600 hover:text-gray-800"
                    )}
                >
                    🇮🇳 हिंदी
                </button>
                <button
                    type="button"
                    onClick={() => setLanguage('hinglish')}
                    className={cn(
                        "flex-1 py-2.5 text-sm font-bold rounded-md transition-all",
                        language === 'hinglish' ? "bg-white text-indigo-700 shadow-sm" : "text-gray-600 hover:text-gray-800"
                    )}
                >
                    🔤 Hinglish
                </button>
            </div>

            {/* Generate Button - BIGGER, MORE PROMINENT */}
            <button
                type="submit"
                disabled={isGenerating}
                className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-bold py-5 rounded-xl shadow-xl shadow-indigo-300 active:scale-95 transition-all flex items-center justify-center gap-3 text-lg"
                style={businessConfig ? {
                    background: `linear-gradient(135deg, ${businessConfig.primaryColor} 0%, ${businessConfig.primaryColor}dd 100%)`
                } : undefined}
            >
                {isGenerating ? (
                    <>
                        <Loader2 className="animate-spin w-6 h-6" /> बन रहा है...
                    </>
                ) : (
                    <>
                        <Wand2 className="w-6 h-6" /> ऑफर बनाएं
                    </>
                )}
            </button>

        </form>
    );
}
