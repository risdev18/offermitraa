"use client";

import { useRef, useState } from "react";
import html2canvas from "html2canvas";
import { Download, Share2, Loader2, Image as ImageIcon } from "lucide-react";

interface BannerGeneratorProps {
    text: string;
    shopType: string;
    shopName?: string;
}

const BACKGROUNDS = [
    "bg-gradient-to-br from-yellow-100 to-orange-200", // Festival
    "bg-gradient-to-br from-blue-100 to-indigo-200",   // Professional
    "bg-gradient-to-br from-green-100 to-emerald-200", // Fresh
    "bg-gradient-to-br from-purple-100 to-pink-200",   // Trendy
    "bg-white border-2 border-dashed border-red-400",   // Sale
];

export default function BannerGenerator({ text, shopType, shopName }: BannerGeneratorProps) {
    const bannerRef = useRef<HTMLDivElement>(null);
    const [bgIndex, setBgIndex] = useState(0);
    const [isCapturing, setIsCapturing] = useState(false);

    const handleDownload = async () => {
        if (!bannerRef.current) return;
        setIsCapturing(true);

        try {
            const canvas = await html2canvas(bannerRef.current, {
                scale: 2, // High res
                backgroundColor: null,
            });

            const image = canvas.toDataURL("image/png");
            const link = document.createElement("a");
            link.href = image;
            link.download = `offer-mitra-${Date.now()}.png`;
            link.click();
        } catch (err) {
            console.error("Capture failed", err);
        } finally {
            setIsCapturing(false);
        }
    };

    return (
        <div className="space-y-4">
            {/* Background Selector */}
            <div className="flex gap-2 overflow-x-auto pb-2">
                {BACKGROUNDS.map((bg, i) => (
                    <button
                        key={i}
                        onClick={() => setBgIndex(i)}
                        className={`w-10 h-10 rounded-full ${bg} ${bgIndex === i ? "ring-2 ring-indigo-600 scale-110" : ""
                            } transition-all shadow-sm`}
                    />
                ))}
            </div>

            {/* Canvas Area */}
            <div
                ref={bannerRef}
                className={`p-6 rounded-xl shadow-lg min-h-[300px] flex flex-col justify-center items-center text-center space-y-4 ${BACKGROUNDS[bgIndex]}`}
            >
                <div className="bg-white/80 backdrop-blur-sm p-2 px-4 rounded-full text-xs font-bold uppercase tracking-wider text-gray-800 border border-white/50">
                    {shopName || `${shopType} Offer`}
                </div>

                <div className="text-xl font-bold text-gray-900 whitespace-pre-wrap leading-relaxed drop-shadow-sm font-sans">
                    {text.replace(/\*/g, "")} {/* Remove markdown stars for image */}
                </div>

                <div className="text-xs text-gray-600 mt-4 font-medium bg-white/50 px-3 py-1 rounded-md">
                    Created with OfferMitra 🚀
                </div>
            </div>

            {/* Actions */}
            <div className="flex gap-2">
                <button
                    onClick={handleDownload}
                    disabled={isCapturing}
                    className="flex-1 bg-indigo-600 text-white py-2 rounded-xl font-medium flex items-center justify-center gap-2 hover:bg-indigo-700 transition-colors"
                >
                    {isCapturing ? <Loader2 className="animate-spin w-4 h-4" /> : <Download className="w-4 h-4" />}
                    Download Image
                </button>
            </div>
        </div>
    );
}
