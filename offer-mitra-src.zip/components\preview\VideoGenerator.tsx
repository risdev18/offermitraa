"use client";

import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useState } from "react";
import { Sparkles, ShoppingBag, Music } from "lucide-react";
import { cn } from "@/lib/utils";

interface VideoGeneratorProps {
    offerText: string;
    productName: string;
    discount: string;
    shopType: string;
    shopName?: string;
}

export default function VideoGenerator({ offerText, productName, discount, shopType, shopName }: VideoGeneratorProps) {
    const [scene, setScene] = useState(0);

    // Scene transition logic
    useEffect(() => {
        const interval = setInterval(() => {
            setScene((prev) => (prev + 1) % 4);
        }, 3000);
        return () => clearInterval(interval);
    }, []);

    const scenes = [
        {
            bg: "bg-indigo-600",
            icon: <ShoppingBag className="w-16 h-16 text-white mb-4" />,
            title: (shopName || "SPECIAL OFFER").toUpperCase(),
            subtitle: shopName ? "OFFER MITRA" : shopType.toUpperCase(),
            animation: { y: [20, -10, 0], scale: [0.8, 1.1, 1] }
        },
        {
            bg: "bg-purple-600",
            icon: <Sparkles className="w-16 h-16 text-white mb-4" />,
            title: productName.toUpperCase(),
            subtitle: "AVAILABLE NOW",
            animation: { x: [-100, 20, 0], opacity: [0, 1] }
        },
        {
            bg: "bg-orange-500",
            icon: <div className="text-6xl font-black text-white mb-4">{discount}</div>,
            title: "FLAT DISCOUNT",
            subtitle: "LIMIT TIME ONLY",
            animation: { scale: [0, 1.5, 1], rotate: [0, 10, 0] }
        },
        {
            bg: "bg-green-600",
            icon: <Music className="w-16 h-16 text-white mb-4" />,
            title: "TAP TO BUY",
            subtitle: "VISIT US TODAY",
            animation: { opacity: [0, 1], y: [50, 0] }
        }
    ];

    return (
        <div className="relative w-full max-w-[320px] aspect-[9/16] rounded-3xl overflow-hidden shadow-2xl bg-black mx-auto border-4 border-gray-800">
            {/* Animated Background */}
            <AnimatePresence mode="wait">
                <motion.div
                    key={scene}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.5 }}
                    className={cn("absolute inset-0 flex flex-col items-center justify-center text-center p-8", scenes[scene].bg)}
                >
                    {/* Floating Ornaments */}
                    <div className="absolute top-10 left-10 w-20 h-20 bg-white/10 rounded-full blur-2xl animate-pulse" />
                    <div className="absolute bottom-20 right-10 w-32 h-32 bg-black/10 rounded-full blur-3xl animate-pulse" />

                    <motion.div
                        animate={scenes[scene].animation}
                        transition={{ duration: 0.8, ease: "easeOut" }}
                    >
                        {scenes[scene].icon}
                        <h2 className="text-4xl font-black text-white leading-tight mb-2 tracking-tighter">
                            {scenes[scene].title}
                        </h2>
                        <div className="inline-block px-4 py-1 bg-black/20 rounded-full text-white/90 text-sm font-bold tracking-widest">
                            {scenes[scene].subtitle}
                        </div>
                    </motion.div>

                    {/* Footer Text */}
                    <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.5 }}
                        className="absolute bottom-10 left-0 right-0 px-6"
                    >
                        <p className="text-white/70 text-xs font-medium leading-relaxed italic">
                            {offerText.slice(0, 60)}...
                        </p>
                    </motion.div>
                </motion.div>
            </AnimatePresence>

            {/* Video Progress Bars */}
            <div className="absolute top-4 left-4 right-4 flex gap-1">
                {[0, 1, 2, 3].map((i) => (
                    <div key={i} className="h-1 flex-1 bg-white/20 rounded-full overflow-hidden">
                        {scene === i && (
                            <motion.div
                                initial={{ width: "0%" }}
                                animate={{ width: "100%" }}
                                transition={{ duration: 3, ease: "linear" }}
                                className="h-full bg-white"
                            />
                        )}
                        {scene > i && <div className="h-full w-full bg-white" />}
                    </div>
                ))}
            </div>

            {/* Simulated UI Overlay */}
            <div className="absolute right-4 bottom-24 flex flex-col gap-4 text-white">
                <div className="flex flex-col items-center"><div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">❤️</div><span className="text-[10px] mt-1">2.4k</span></div>
                <div className="flex flex-col items-center"><div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">💬</div><span className="text-[10px] mt-1">128</span></div>
                <div className="flex flex-col items-center"><div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">🔗</div><span className="text-[10px] mt-1">Share</span></div>
            </div>
        </div>
    );
}
