import { NextResponse } from "next/server";
import fs from "fs";
import path from "path";

const DATA_FILE = path.join(process.cwd(), "data", "access-codes.json");

// Read codes from file
function readCodes() {
    const dataDir = path.join(process.cwd(), "data");
    if (!fs.existsSync(dataDir)) {
        return [];
    }
    if (!fs.existsSync(DATA_FILE)) {
        return [];
    }
    const data = fs.readFileSync(DATA_FILE, "utf-8");
    return JSON.parse(data);
}

// Write codes to file
function writeCodes(codes: any[]) {
    const dataDir = path.join(process.cwd(), "data");
    if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
    }
    fs.writeFileSync(DATA_FILE, JSON.stringify(codes, null, 2));
}

export async function POST(req: Request) {
    try {
        const { code } = await req.json();

        if (!code) {
            return NextResponse.json({ error: "Code is required" }, { status: 400 });
        }

        const codes = readCodes();
        const codeData = codes.find((c: any) => c.code === code.trim().toUpperCase());

        if (!codeData) {
            return NextResponse.json({ error: "Invalid Access Code" }, { status: 404 });
        }

        // 1. Check if Active
        if (!codeData.isActive) {
            return NextResponse.json({ error: "This code is disabled" }, { status: 403 });
        }

        // 2. Check if already Used
        if (codeData.isUsed) {
            return NextResponse.json({ error: "This code has already been used" }, { status: 403 });
        }

        // 3. Check Expiry
        if (codeData.expiryDate && codeData.expiryDate < Date.now()) {
            return NextResponse.json({ error: "This code has expired" }, { status: 403 });
        }

        // Mark as used
        codeData.isUsed = true;
        codeData.usedAt = Date.now();
        writeCodes(codes);

        return NextResponse.json({
            success: true,
            message: "Pro Status Unlocked! 🎉"
        });

    } catch (error: any) {
        console.error("Validation error:", error);
        return NextResponse.json({ error: "Internal server error" }, { status: 500 });
    }
}
