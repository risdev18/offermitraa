"use client";

import { useState, useEffect } from "react";
import { Sparkles, Loader2, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface Suggestion {
    title: string;
    product: string;
    discount: string;
}

interface AIIdeasProps {
    shopType: string;
    onSelectSuggestion: (suggestion: Suggestion) => void;
}

export default function AIIdeas({ shopType, onSelectSuggestion }: AIIdeasProps) {
    const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
    const [loading, setLoading] = useState(false);

    const fetchSuggestions = async () => {
        if (!shopType) return;
        setLoading(true);
        try {
            const res = await fetch("/api/suggestions", {
                method: "POST",
                body: JSON.stringify({ shopType }),
            });
            const data = await res.json();
            if (data.suggestions) {
                setSuggestions(data.suggestions);
            }
        } catch (error) {
            console.error("Fetch Suggestions Error:", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchSuggestions();
    }, [shopType]);

    return (
        <div className="space-y-3 bg-indigo-50/50 p-4 rounded-2xl border border-indigo-100">
            <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-indigo-800 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4" /> AI Ideas for {shopType.charAt(0).toUpperCase() + shopType.slice(1)}
                </h3>
                <button
                    onClick={fetchSuggestions}
                    className="text-[10px] font-bold uppercase tracking-wider text-indigo-500 hover:text-indigo-700"
                >
                    Refresh
                </button>
            </div>

            {loading ? (
                <div className="flex items-center justify-center py-4">
                    <Loader2 className="w-5 h-5 animate-spin text-indigo-400" />
                </div>
            ) : (
                <div className="flex flex-col gap-2">
                    {suggestions.map((s, i) => (
                        <button
                            key={i}
                            type="button"
                            onClick={() => onSelectSuggestion(s)}
                            className="text-left p-3 bg-white border border-indigo-100 rounded-xl hover:border-indigo-500 hover:shadow-md transition-all group active:scale-[0.98]"
                        >
                            <div className="flex justify-between items-start mb-1">
                                <span className="text-xs font-bold text-gray-900 group-hover:text-indigo-600 line-clamp-1">{s.title}</span>
                                <ArrowRight className="w-3 h-3 text-indigo-300 group-hover:text-indigo-500 transition-transform group-hover:translate-x-0.5" />
                            </div>
                            <div className="flex gap-2">
                                <span className="text-[10px] px-1.5 py-0.5 bg-slate-100 rounded text-gray-500">{s.product}</span>
                                <span className="text-[10px] px-1.5 py-0.5 bg-green-50 text-green-700 rounded font-bold">{s.discount}</span>
                            </div>
                        </button>
                    ))}
                </div>
            )}
        </div>
    );
}
