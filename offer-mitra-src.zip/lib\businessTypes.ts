// Business type configuration and utilities

export type BusinessType = 'grocery' | 'mobile' | 'medical' | 'clothing' | 'restaurant' | 'hardware';

export interface BusinessConfig {
    id: BusinessType;
    name: string;
    nameHindi: string;
    icon: string;
    primaryColor: string;
    secondaryColor: string;
    defaultCTA: string;
    defaultCTAHindi: string;
    secondaryCTA: string;
    tone: 'urgent' | 'trust' | 'value' | 'premium';
    suggestedOffers: string[];
}

export const BUSINESS_TYPES: Record<BusinessType, BusinessConfig> = {
    grocery: {
        id: 'grocery',
        name: 'Grocery/Kirana',
        nameHindi: 'किराना/ग्रोसरी',
        icon: '🛒',
        primaryColor: '#16a34a', // Green
        secondaryColor: '#dcfce7',
        defaultCTA: 'Call for Home Delivery',
        defaultCTAHindi: 'होम डिलीवरी के लिए कॉल करें',
        secondaryCTA: 'WhatsApp Order',
        tone: 'value',
        suggestedOffers: ['Combo Pack', 'Free Delivery', 'Daily Essentials']
    },
    mobile: {
        id: 'mobile',
        name: 'Mobile/Electronics',
        nameHindi: 'मोबाइल/इलेक्ट्रॉनिक्स',
        icon: '📱',
        primaryColor: '#2563eb', // Blue
        secondaryColor: '#dbeafe',
        defaultCTA: 'Visit Showroom Today',
        defaultCTAHindi: 'आज शोरूम आएं',
        secondaryCTA: 'Call for Best Price',
        tone: 'premium',
        suggestedOffers: ['Exchange Offer', 'EMI Available', 'Accessories Free']
    },
    medical: {
        id: 'medical',
        name: 'Medical/Pharmacy',
        nameHindi: 'मेडिकल/फार्मेसी',
        icon: '💊',
        primaryColor: '#0891b2', // Cyan
        secondaryColor: '#cffafe',
        defaultCTA: 'Order on WhatsApp',
        defaultCTAHindi: 'WhatsApp पर ऑर्डर करें',
        secondaryCTA: 'Call Now',
        tone: 'trust',
        suggestedOffers: ['Health Checkup', 'Medicine Discount', 'Free Consultation']
    },
    clothing: {
        id: 'clothing',
        name: 'Clothing/Fashion',
        nameHindi: 'कपड़े/फैशन',
        icon: '👕',
        primaryColor: '#dc2626', // Red
        secondaryColor: '#fee2e2',
        defaultCTA: 'Visit Store',
        defaultCTAHindi: 'स्टोर पर आएं',
        secondaryCTA: 'See More Designs',
        tone: 'urgent',
        suggestedOffers: ['Clearance Sale', 'New Collection', 'Buy 2 Get 1']
    },
    restaurant: {
        id: 'restaurant',
        name: 'Restaurant/Food',
        nameHindi: 'रेस्टोरेंट/खाना',
        icon: '🍽️',
        primaryColor: '#ea580c', // Orange
        secondaryColor: '#ffedd5',
        defaultCTA: 'Order Now',
        defaultCTAHindi: 'अभी ऑर्डर करें',
        secondaryCTA: 'Book Table',
        tone: 'urgent',
        suggestedOffers: ['Combo Meal', 'Family Pack', 'Sunday Special']
    },
    hardware: {
        id: 'hardware',
        name: 'Hardware/Tools',
        nameHindi: 'हार्डवेयर/औजार',
        icon: '🔧',
        primaryColor: '#65a30d', // Lime
        secondaryColor: '#ecfccb',
        defaultCTA: 'Visit Shop',
        defaultCTAHindi: 'दुकान पर आएं',
        secondaryCTA: 'Call for Quote',
        tone: 'value',
        suggestedOffers: ['Bulk Discount', 'Contractor Special', 'Quality Tools']
    }
};

export function getBusinessConfig(type: BusinessType): BusinessConfig {
    return BUSINESS_TYPES[type];
}

export function saveBusinessType(type: BusinessType): void {
    localStorage.setItem('om_business_type', type);
}

export function getBusinessType(): BusinessType | null {
    if (typeof window === 'undefined') return null;
    return localStorage.getItem('om_business_type') as BusinessType | null;
}

export function clearBusinessType(): void {
    localStorage.removeItem('om_business_type');
}
