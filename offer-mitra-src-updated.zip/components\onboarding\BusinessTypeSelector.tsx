"use client";

import { useState } from "react";
import { BUSINESS_TYPES, BusinessType, saveBusinessType } from "@/lib/businessTypes";
import { X } from "lucide-react";

interface BusinessTypeSelectorProps {
    onSelect: (type: BusinessType) => void;
    onSkip?: () => void;
}

export default function BusinessTypeSelector({ onSelect, onSkip }: BusinessTypeSelectorProps) {
    const [selected, setSelected] = useState<BusinessType | null>(null);

    const handleSelect = (type: BusinessType) => {
        setSelected(type);
    };

    const handleConfirm = () => {
        if (selected) {
            saveBusinessType(selected);
            onSelect(selected);
        }
    };

    return (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">

                {/* Header */}
                <div className="sticky top-0 bg-white border-b border-gray-100 p-6 rounded-t-3xl">
                    <div className="flex justify-between items-start">
                        <div>
                            <h2 className="text-2xl font-bold text-gray-900 mb-2">
                                अपना बिज़नेस चुनें
                            </h2>
                            <p className="text-gray-700 text-sm">
                                आपके बिज़नेस के हिसाब से ऑफर बनाएंगे
                            </p>
                        </div>
                        {onSkip && (
                            <button
                                onClick={onSkip}
                                className="text-gray-400 hover:text-gray-600 p-2"
                            >
                                <X className="w-5 h-5" />
                            </button>
                        )}
                    </div>
                </div>

                {/* Business Type Grid */}
                <div className="p-6 grid grid-cols-2 md:grid-cols-3 gap-4">
                    {Object.values(BUSINESS_TYPES).map((business) => (
                        <button
                            key={business.id}
                            onClick={() => handleSelect(business.id)}
                            className={`
                                relative p-6 rounded-2xl border-2 transition-all
                                ${selected === business.id
                                    ? 'border-indigo-600 bg-indigo-50 shadow-lg scale-105'
                                    : 'border-gray-200 hover:border-gray-300 hover:shadow-md'
                                }
                            `}
                        >
                            {/* Icon */}
                            <div className="text-5xl mb-3">{business.icon}</div>

                            {/* Name */}
                            <div className="text-sm font-bold text-gray-900 mb-1">
                                {business.nameHindi}
                            </div>
                            <div className="text-xs text-gray-600">
                                {business.name}
                            </div>

                            {/* Selected Indicator */}
                            {selected === business.id && (
                                <div className="absolute top-3 right-3 w-6 h-6 bg-indigo-600 rounded-full flex items-center justify-center">
                                    <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                                    </svg>
                                </div>
                            )}
                        </button>
                    ))}
                </div>

                {/* Footer */}
                <div className="sticky bottom-0 bg-white border-t border-gray-100 p-6 rounded-b-3xl">
                    <button
                        onClick={handleConfirm}
                        disabled={!selected}
                        className={`
                            w-full py-4 rounded-xl font-bold text-lg transition-all
                            ${selected
                                ? 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg shadow-indigo-200'
                                : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                            }
                        `}
                    >
                        {selected ? '✓ Continue' : 'Select Business Type'}
                    </button>

                    {selected && (
                        <p className="text-center text-xs text-gray-500 mt-3">
                            आप बाद में भी बदल सकते हैं
                        </p>
                    )}
                </div>
            </div>
        </div>
    );
}
