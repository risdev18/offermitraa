// Business type definitions and configuration
export type BusinessType = 'grocery' | 'mobile' | 'medical' | 'clothing' | 'restaurant' | 'hardware' | 'other';

export interface BusinessConfig {
    primaryColor: string; // hex color for UI theme
    ctaText: string; // default CTA button label
    tone: 'friendly' | 'exciting' | 'trustworthy' | 'stylish';
    defaultTemplate: 'urgent' | 'sunday' | 'festival' | 'clearance';
}

export const BUSINESS_CONFIG: Record<BusinessType, BusinessConfig> = {
    grocery: {
        primaryColor: '#22c55e', // green
        ctaText: 'Call Now',
        tone: 'friendly',
        defaultTemplate: 'urgent',
    },
    mobile: {
        primaryColor: '#3b82f6', // blue
        ctaText: 'Visit Today',
        tone: 'exciting',
        defaultTemplate: 'clearance',
    },
    medical: {
        primaryColor: '#10b981', // teal
        ctaText: 'WhatsApp Us',
        tone: 'trustworthy',
        defaultTemplate: 'festival',
    },
    clothing: {
        primaryColor: '#f97316', // orange
        ctaText: 'Visit Today',
        tone: 'stylish',
        defaultTemplate: 'sunday',
    },
    restaurant: {
        primaryColor: '#ef4444', // red
        ctaText: 'Reserve Table',
        tone: 'friendly',
        defaultTemplate: 'sunday',
    },
    hardware: {
        primaryColor: '#8b5cf6', // purple
        ctaText: 'Call Now',
        tone: 'trustworthy',
        defaultTemplate: 'clearance',
    },
    other: {
        primaryColor: '#6366f1', // indigo
        ctaText: 'Contact Us',
        tone: 'friendly',
        defaultTemplate: 'urgent',
    },
};

/** Helper to get stored business type from localStorage */
export const getStoredBusinessType = (): BusinessType | null => {
    if (typeof window === 'undefined') return null;
    const val = localStorage.getItem('businessType');
    return val as BusinessType | null;
};

/** Save selected business type */
export const setStoredBusinessType = (type: BusinessType) => {
    if (typeof window !== 'undefined') {
        localStorage.setItem('businessType', type);
    }
};

/** Exported alias used by components */
export const saveBusinessType = setStoredBusinessType;

/** Get config for current or default business type */
export const getBusinessConfig = (type: BusinessType | null): BusinessConfig => {
    return type && BUSINESS_CONFIG[type] ? BUSINESS_CONFIG[type] : BUSINESS_CONFIG['grocery'];
};

/** Business type list for selector UI */
import { ShoppingBag, Smartphone, HeartPulse, Shirt, Utensils, Wrench, MoreHorizontal } from 'lucide-react';
export const BUSINESS_TYPES: Record<BusinessType, { id: BusinessType; name: string; nameHindi: string; icon: JSX.Element }> = {
    grocery: { id: 'grocery', name: 'Grocery/Kirana', nameHindi: 'किराना', icon: <ShoppingBag size={ 32} /> },
mobile: { id: 'mobile', name: 'Mobile/Electronics', nameHindi: 'मोबाइल', icon: <Smartphone size={ 32 } /> },
medical: { id: 'medical', name: 'Medical/Pharmacy', nameHindi: 'मेडिकल', icon: <HeartPulse size={ 32 } /> },
clothing: { id: 'clothing', name: 'Clothing/Fashion', nameHindi: 'कपड़े', icon: <Shirt size={ 32 } /> },
restaurant: { id: 'restaurant', name: 'Restaurant/Food', nameHindi: 'रेस्टोरेंट', icon: <Utensils size={ 32 } /> },
hardware: { id: 'hardware', name: 'Hardware/Tools', nameHindi: 'हार्डवेयर', icon: <Wrench size={ 32 } /> },
other: { id: 'other', name: 'Other', nameHindi: 'अन्य', icon: <MoreHorizontal size={ 32 } /> },
};
